/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            molpayseamlessdeco: 'https://www.onlinepayment.com.my/MOLPay/API/seamless/3.11/js/MOLPay_seamless.deco.js?v=9'
        }
    }
};
